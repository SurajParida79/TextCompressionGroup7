import binaryconversion


def read_Text(file_path):
    my_file = open(file_path, "r", encoding='utf-8')
    string = my_file.read()
    return string


string = read_Text("BinOutput.txt")
ans = binaryconversion.letters(string)
compress_file = open("BinOutput.txt", "w")
compress_file.write(str(len(ans)) + "." + ans)
compress_file.close()
