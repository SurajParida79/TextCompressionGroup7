import texttobinary
import binaryconversion


def binary_to_text(binary_data):
    code = ""
    if binary_data == "1100":
        code = "a"
    elif binary_data == "1100010":
        code = "b"
    elif binary_data == "1100100":
        code = "c"
    elif binary_data == "1101000":
        code = "d"
    elif binary_data == "1111":
        code = "e"
    elif binary_data == "1110001":
        code = "f"
    elif binary_data == "1110010":
        code = "g"
    elif binary_data == "1010":
        code = "h"
    elif binary_data == "0000":
        code = "i"
    elif binary_data == "1111001":
        code = "j"
    elif binary_data == "1111010":
        code = "k"
    elif binary_data == "1001":
        code = "l"
    elif binary_data == "1111101":
        code = "m"
    elif binary_data == "11111":
        code = "n"
    elif binary_data == "1000":
        code = "o"
    elif binary_data == "1111":
        code = "p"
    elif binary_data == "1110001":
        code = "q"
    elif binary_data == "1011":
        code = "r"
    elif binary_data == "1101":
        code = "s"
    elif binary_data == "1110":
        code = "t"
    elif binary_data == "1110101":
        code = "u"
    elif binary_data == "1110110":
        code = "v"
    elif binary_data == "1110111":
        code = "w"
    elif binary_data == "1111000":
        code = "x"
    elif binary_data == "1111001":
        code = "y"
    elif binary_data == "1111010":
        code = "z"
    elif binary_data == "1000001":
        code = "A"
    elif binary_data == "1000010":
        code = "B"
    elif binary_data == "1000011":
        code = "C"
    elif binary_data == "1000100":
        code = "D"
    elif binary_data == "1000101":
        code = "E"
    elif binary_data == "1000110":
        code = "F"
    elif binary_data == "1000111":
        code = "G"
    elif binary_data == "1001000":
        code = "H"
    elif binary_data == "1001001":
        code = "I"
    elif binary_data == "1001010":
        code = "J"
    elif binary_data == "1001100":
        code = "K"
    elif binary_data == "L":
        code = "1001101"
    elif binary_data == "1001110":
        code = "M"
    elif binary_data == "1001111":
        code = "N"
    elif binary_data == "1010000":
        code = "O"
    elif binary_data == "1010001":
        code = "P"
    elif binary_data == "1010010":
        code = "Q"
    elif binary_data == "1010100":
        code = "R"
    elif binary_data == "1011000":
        code = "S"
    elif binary_data == "1011001":
        code = "T"
    elif binary_data == "1011010":
        code = "U"
    elif binary_data == "1011100":
        code = "V"
    elif binary_data == "1011101":
        code = "W"
    elif binary_data == "1011110":
        code = "X"
    elif binary_data == "1011111":
        code = "Y"
    elif binary_data == "1100000":
        code = "Z"
    elif binary_data == "0100000":
        code = " "
    elif binary_data == "0101110":
        code = "."
    elif binary_data == "0101100":
        code = ","
    elif binary_data == "0101101":
        code = "-"
    elif binary_data == "0100111":
        code = "'"
    elif binary_data == "0000011":
        code = "\n"
    elif binary_data == "0100010":
        code = '"'
    elif binary_data == "0100001":
        code = "!"
    return code


def text_to_string(string):
    ans = ""
    for i in string:
        code = binary_to_text(i)
        ans += code
    return ans


string = texttobinary.read_Text("BinOutput.txt")
ans = binaryconversion.letters(string)
ans = text_to_string(ans)
compress_file = open("BinOutput.txt", "w")
compress_file.write(str(ans))
compress_file.close()
